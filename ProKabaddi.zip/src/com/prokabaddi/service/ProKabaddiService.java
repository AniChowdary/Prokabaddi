/*---------------------------------------------------------------------------------------
 * Object Name: ProKabaddiService.Java
 * 
 * Modification Block:
 * --------------------------------------------------------------------------------------
 * S.No. Name                Date      Bug Fix no. Desc
 * --------------------------------------------------------------------------------------
 * 1     Seshadri Chowdary          07/08/16  NA          Created
 * --------------------------------------------------------------------------------------
 *
 * Copyright: 2016 <Seshadri Chowdary>
 *---------------------------------------------------------------------------------------*/

package com.prokabaddi.service;

import java.util.List;

import com.prokabaddi.exception.ServiceException;
import com.prokabaddi.model.DTO.ProKabaddiDaysDtlDTO;

public interface ProKabaddiService {

	List<ProKabaddiDaysDtlDTO> proSechdule(String noTeam) throws ServiceException;

	List<ProKabaddiDaysDtlDTO> getMatchesData(ProKabaddiDaysDtlDTO proKabaddiDaysDtlDTO,
			String userId, String path) throws ServiceException;

}

/*---------------------------------------------------------------------------------------
 * Object Name: DoubleRoundRabiBuilder.Java
 * 
 * Modification Block:
 * --------------------------------------------------------------------------------------
 * S.No. Name                Date      Bug Fix no. Desc
 * --------------------------------------------------------------------------------------
 * 1     Seshadri Chowdary          07/08/16  NA          Created
 * --------------------------------------------------------------------------------------
 *
 * Copyright: 2016 <Seshadri Chowdary>
 *---------------------------------------------------------------------------------------*/

package com.prokabaddi.builder;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import com.prokabaddi.model.DTO.ProKabaddiDaysDtlDTO;

public class DoubleRoundRabiBuilder {

	public static void main(String[] args) {

		// obtain the number of teams from user input
		Scanner input = new Scanner(System.in);
		System.out.print("How many teams should the fixture table have?");

		int teams;
		teams = input.nextInt();
		// listMatches(teams);
		/*
		 * int[][] abc = getCal(teams); for (int[] is : abc) {
		 * System.out.println(is); }
		 */
		// listMatches(teams);
		List<String> teamsList = new ArrayList<String>();
		for (int i = 1; i <= teams; i++) {
			teamsList.add(i + "");
		}
		// listMatches(teamsList);
		btnTeamFixturesClick(teamsList);

	}

	public static void listMatches(int teams) {

		// Generate the schedule using round robin algorithm.
		int matchesPerDay = 2;
		int totalDays = (teams - 1) * (teams) / matchesPerDay;
		int halfDayMark = (matchesPerDay / 2);
		String[][] days = new String[totalDays][matchesPerDay];

		for (int day = 0; day < totalDays; day++) {

			for (int match = 0; match < matchesPerDay; match++) {
				int home = (day + match) % (teams - 1);
				int away = (teams - 1 - match + day) % (teams - 1);

				// Last team stays in the same place while the others
				// rotate around it.
				if (match == 0) {
					away = teams - 1;
				}

				// Add one so teams are number 1 to teams not 0 to teams - 1
				// upon display.
				String roundString;
				if (day < halfDayMark) {
					roundString = (" " + (home + 1) + " - " + (away + 1));
				} else {
					roundString = (" " + (away + 1) + " - " + (home + 1));
				}
				days[day][match] = roundString;

				// days[day][match] = (" " + (home + 1) + " - " + (away + 1));
			}
		}

		// Display the days
		for (int i = 0; i < days.length; i++) {
			System.out.println("Day " + (i + 1));
			System.out.println(Arrays.asList(days[i]));
			System.out.println();
		}
	}

	public static int[][] getCal(int nbParticipants) {
		int k;

		int[][] calender = new int[nbParticipants][nbParticipants - 1];

		for (int l = 0; l < nbParticipants - 1; l++) {

			k = nbParticipants - l;
			for (int c = 0; c < nbParticipants - 1; c++) {

				if (l + 1 == k) {
					calender[l][c] = nbParticipants;
				} else {
					calender[l][c] = k;

				}
				k--;
				if (k == 0) {
					k = nbParticipants - 1;
				}
			}

		}

		for (int c = 0; c < nbParticipants - 1; c++) {
			for (int l = 0; l < nbParticipants - 1; l++) {
				if (calender[l][c] == nbParticipants) {
					calender[nbParticipants - 1][c] = l + 1;
				}
			}
		}

		return calender;
	}

	public static void listMatches(List<String> listTeam) {
		if (listTeam.size() % 2 != 0) {
			listTeam.add("Bye"); // If odd number of teams add a dummy
		}

		// Days needed to complete tournament
		int numDays = ((listTeam.size() - 1) * listTeam.size()) / 2;

		int halfSize = listTeam.size() / 2;

		// Add teams to List and remove the first team
		List<String> teams = new ArrayList<String>(listTeam);

		teams.remove(0);
		int teamsSize = teams.size();

		for (int day = 0; day < numDays; day++) {
			System.out.println("Day " + (day + 1));

			int teamIdx = day % teamsSize;

			System.out.println("" + teams.get(teamIdx) + " vs " + listTeam.get(0));

			for (int idx = 1; idx < halfSize - 2; idx++) {
				int firstTeam = (day + idx) % teamsSize;
				int secondTeam = (day + teamsSize - idx) % teamsSize;
				System.out.println("" + teams.get(firstTeam) + " vs " + teams.get(secondTeam));
			}
		}
	}

	public static List<ProKabaddiDaysDtlDTO> btnTeamFixturesClick(List<String> listTeam) {
		if (listTeam.size() % 2 != 0) {
			listTeam.add("Bye"); // If odd number of teams add a dummy
		}

		// Days needed to complete tournament
		int machesPerDay = 4;
		int numDays = ((listTeam.size() - 1) * listTeam.size()) / machesPerDay;

		int halfSize = listTeam.size() / 2;
		List<String> temp = new ArrayList<String>(listTeam);
		List<String> teams = new ArrayList<String>(listTeam);

		List<ProKabaddiDaysDtlDTO> maindata = new ArrayList<ProKabaddiDaysDtlDTO>();
		List<String> data = null;
		ProKabaddiDaysDtlDTO maindataDto = null;
		teams.remove(0);

		int teamSize = teams.size();

		for (int day = 0; day < numDays; day++) {
			data = new ArrayList<String>();
			maindataDto = new ProKabaddiDaysDtlDTO();
			// Calculate1stRound(day);
			if (day % 2 == 0) {
				maindataDto.setDay("Day " + (day + 1));
				int teamIdx = day % teamSize;

				data.add(teams.get(teamIdx) + " vs " + temp.get(0));
				for (int idx = 0; idx < halfSize; idx++) {
					int firstTeam = (day + idx) % teamSize;
					int secondTeam = ((day + teamSize) - idx) % teamSize;

					if (firstTeam != secondTeam) {
						data.add(teams.get(firstTeam) + " vs " + teams.get(secondTeam));

					}
				}
				maindataDto.setMatch(data);
			}

			// Calculate2ndRound(day);
			if (day % 2 != 0) {
				int teamIdx = day % teamSize;

				maindataDto.setDay("Day " + (day + 1));

				data.add(temp.get(0) + " vs " + teams.get(teamIdx));
				for (int idx = 0; idx < halfSize; idx++) {
					int firstTeam = (day + idx) % teamSize;
					int secondTeam = ((day + teamSize) - idx) % teamSize;

					if (firstTeam != secondTeam) {
						data.add(teams.get(secondTeam) + " vs " + teams.get(firstTeam));
					}
				}
				maindataDto.setMatch(data);
			}
			maindata.add(maindataDto);
		}
		return maindata;
	}

}

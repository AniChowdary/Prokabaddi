/*---------------------------------------------------------------------------------------
 * Object Name: ProKabaddiLoggerConstants.Java
 * 
 * Modification Block:
 * --------------------------------------------------------------------------------------
 * S.No. Name                Date      Bug Fix no. Desc
 * --------------------------------------------------------------------------------------
 * 1     Seshadri Chowdary          07/08/16  NA          Created
 * --------------------------------------------------------------------------------------
 *
 * Copyright: 2016 <Seshadri Chowdary>
 *---------------------------------------------------------------------------------------*/

package com.prokabaddi.constant;

/**
 * Class which will provides the String final constants i.e JSP names, request
 * handler mappings, request parameters , strings and error codes.
 */

public final class ProKabaddiLoggerConstants {

	public static final String PRO_LOGIN_REDIRECT = "login:redirect?accessDenied=true";
	public static final String PRO_LOGIN_SESSIONEXP = "/sessionExp";
	public static final String PRO_LOGIN_AUTHFAIL = "/authFail";
	public static final String PRO_LOGIN_BACK = "/back";
	public static final String PRO_LOOUT = "/logout";

	// View
	public static final String PRO_LOGIN_VIEW = "login";

	public static final String LOGOUT = "logout";
	public static final String INVALID_UNAME_PASS = "Invalid username and password!";
	public static final String LOGOUT_SUCCESS = "You've been logged out successfully.";
	public static final String SESSION_EXPIRED = "You are not allowed to perform 'Back' or You have not logged in or Session Expired.";
	public static final String NEW_USER = "You are not a registered user, Please request for providing the access.";

	// Logger classes

	public static final String PRO_LOGIN_CTLR = "~ ProKabaddiLoginController ~";
	public static final String PRO_LOGIN_CTLR_GET = "~ login ~";
	public static final String PRO_LOGIN_CTLR_YES = "~ login Params:Yes ~";
	public static final String PRO_CTLR_NO_PARAMS = "~ Params:No ~";

	public static final String PRO_LOGIN_CTLR_INDEX = "~ index ~";

	public static final String PRO_LOGIN_CTLR_SESS_EXP = "~ session exp ~";

	public static final String PRO_LOGIN_CTLR_AUTH_FAIL = "~ authFail ~";

	public static final String PRO_LOGIN_CTLR_BACK_TO_LOGIN = "~ backToLogin ~";

	public static final String PRO_LOGIN_CTLR_LOGOUT = "~ logoutPage ~";

	public static final String PRO_LOGOUT_CTLR_GET = "~ logout ~";

	public static final String PRO_USER_AUTH_HANDLER = "~ UserAuthenticationSuccessHandler ~";
	public static final String PRO_USER_AUTH_HANDLER_ONAUTH = "~ onAuthenticationSuccess ~";

	public static final String PRO_USER_AUTH_HANDLER_HANDLE = "~ handle ~";
	public static final String PRO_USER_AUTH_HANDLER_HANDLE_NO = "~ handle Params:No ~";

	public static final String PRO_USER_AUTH_HANDLER_TAR_URL = "~ determineTargetUrl ~";
	public static final String PRO_USER_AUTH_HANDLER_TAR_URL_RETN = "~ Return ~";

	public static final String PRO_USER_AUTH_HANDLER_CLR_AUTH = "~ clearAuthenticationAttributes ~";
	// download Util

	public static final String LOG_INFO_PARAMS_NO = " Method Begain ~ params : No ";
	public static final String LOG_INFO_RETURN = " next is return ";
	public static final String LOG_ERROR_EXCEPTION = " Exception ";
	public static final String LOG_INFO_PARAMS_YES = " Method Begain ~ params : ";
	public static final String LOG_INFO_REDIRECT = " next is redirecting ";
	public static final String LOG_INFO_DOWNLOAD = " next is downloding xls ";
	public static final String LOG_INFO_PARAMS_SEPC = " Method Begain ~ params : page  ";
	public static final String LOG_INFO_POPUP = " to get popup ~ params : ";
	public static final String LOG_INFO_EXPORT = " Method Begain ~ params : export ";
	public static final String LOG_INFO_REQ_ID = "Method Begain ~ params : reqId";
	public static final String LOG_INFO_SEARCH = " Method Begain ~ params : search ";

	// User Start
	public static final String PRO_USER_CTLR = "~ ProKabaddiUserController ~";
	public static final String PRO_CTLR_PARAM_YES = "~ Params:Yes ~";
	public static final String PRO_CTLR_ERROR = "~ Error ~ : ";

	public static final String PRO_USER_CTLR_CRT_USER = "~ remsCreateUser ~";
	public static final String PRO_USER_CTLR_UPDATE_USER = "~ remsUpdatUser ~";
	public static final String PRO_USER_CTLR_UPDATE_USER_POST = "~ remsUpdatUserPost ~";

	public static final String PRO_USER_CTLR_CRT_USER_POST = "~ remsCreateUserPost ~";
	public static final String PRO_USER_CTLR_VIEW_USER = "~ remsViewUser ~";
	public static final String PRO_USER_CTLR_DEL_USER = "~ daleteUser ~";
	public static final String PRO_USER_CTLR_APP_APPLOC = "~ remsAllocAppUser ~";
	public static final String PRO_USER_CTLR_APP_APPLOC_POST = "~ remsAllocAppUserPost ~";
	public static final String PRO_USER_CTLR_APP_APPLOC_VIEW = "~ remsViewAllocApp ~";
	public static final String PRO_USER_CTLR_APP_APPLOC_DELETE = "~ daleteAllocApp ~";
	public static final String PRO_USER_CTLR_APP_APPLOC_CHECK = "~ remsCheckAllApp ~";
	public static final String PRO_USER_CTLR_CHECK_USER = "~ remsCheckUserAvail ~";

	public static final String PRO_USER_SERVICE = "~ ProKabaddiServiceImpl ~";

	public static final String PRO_USER_EDIT = "~ selectUserToEdit ~";
	public static final String PRO_USER_SAVE = "~ saveUserDetails ~";
	public static final String PRO_USER_UPDATE = "~ updateUser ~";
	public static final String PRO_USER_VIEW_CNT = "~ remsViewUserCnt ~";
	public static final String PRO_USER_VIEW = "~ remsViewUser ~";
	public static final String PRO_USER_DELETE = "~ daleteUser ~";
	public static final String PRO_USER_ACCESS_EDIT = "~ selectUserAccessToEdit ~";
	public static final String PRO_USER_ACCESS_DTL = "~ saveUserAccessDetails ~";
	public static final String PRO_USER_ALLOC_APP_CNT = "~ remsViewAllocAppCnt ~";
	public static final String PRO_USER_ALLOC_APP = "~ remsViewAllocApp ~";
	public static final String PRO_USER_DEL_ALLOC_APP = "~ daleteAllocApp ~";
	public static final String PRO_USER_CHECK_ALL_APP = "~ remsCheckAllApp ~";
	public static final String PRO_USER_CHECK_AVAIL_USER = "~ remsCheckUserAvail ~";

	public static final String PRO_USER_DAO = "~ ProKabaddiDAOImpl ~";

}

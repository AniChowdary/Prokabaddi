/*---------------------------------------------------------------------------------------
 * Object Name: UserAuthenticationSuccessHandler.Java
 * 
 * Modification Block:
 * --------------------------------------------------------------------------------------
 * S.No. Name                Date      Bug Fix no. Desc
 * --------------------------------------------------------------------------------------
 * 1     Seshadri Chowdary          07/08/16  NA          Created
 * --------------------------------------------------------------------------------------
 *
 * Copyright: 2016 <Seshadri Chowdary>
 *---------------------------------------------------------------------------------------*/

package com.prokabaddi.handler;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.WebAttributes;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import com.prokabaddi.constant.ProKabaddiConstants;
import com.prokabaddi.constant.ProKabaddiLoggerConstants;
import com.prokabaddi.constant.ProKabaddiViewsConstants;

/**
 * @author Seshadri Chowdary
 *
 */
public class UserAuthenticationSuccessHandler implements AuthenticationSuccessHandler {
	private static Logger logger = Logger.getLogger(UserAuthenticationSuccessHandler.class);
	private RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();

	public void setRedirectStrategy(RedirectStrategy redirectStrategy) {
		this.redirectStrategy = redirectStrategy;
	}

	protected RedirectStrategy getRedirectStrategy() {
		return redirectStrategy;
	}

	@Override
	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
			Authentication authentication) throws IOException {
		logger.info(ProKabaddiLoggerConstants.PRO_USER_AUTH_HANDLER
				+ ProKabaddiLoggerConstants.PRO_USER_AUTH_HANDLER_HANDLE
				+ ProKabaddiLoggerConstants.LOG_INFO_PARAMS_NO);
		handle(request, response, authentication);
		clearAuthenticationAttributes(request, authentication);
	}

	protected void handle(HttpServletRequest request, HttpServletResponse response,
			Authentication authentication) throws IOException {
		logger.info(ProKabaddiLoggerConstants.PRO_USER_AUTH_HANDLER
				+ ProKabaddiLoggerConstants.PRO_USER_AUTH_HANDLER_HANDLE
				+ ProKabaddiLoggerConstants.LOG_INFO_PARAMS_NO);
		String targetUrl = determineTargetUrl(authentication);

		if (response.isCommitted()) {
			return;
		}
		redirectStrategy.sendRedirect(request, response, targetUrl);
	}

	/**
	 * Builds the target URL according to the logic defined in the main class
	 * Javadoc.
	 */
	protected String determineTargetUrl(Authentication authentication) {
		logger.info(ProKabaddiLoggerConstants.PRO_USER_AUTH_HANDLER
				+ ProKabaddiLoggerConstants.PRO_USER_AUTH_HANDLER_TAR_URL
				+ ProKabaddiLoggerConstants.LOG_INFO_PARAMS_NO);
		boolean isUser = false;
		boolean isAdmin = false;
		Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
		for (GrantedAuthority grantedAuthority : authorities) {
			if (grantedAuthority.getAuthority().equals(ProKabaddiConstants.ROLE_USER)) {
				isUser = true;
				break;
			} else if (grantedAuthority.getAuthority().equals(ProKabaddiConstants.ROLE_ADMIN)) {
				isAdmin = true;
				break;
			}
		}
		if (isUser) {
			return ProKabaddiViewsConstants.PRO_INDEX;
		} else if (isAdmin) {
			return ProKabaddiViewsConstants.PRO_INDEX;
		} else {
			logger.error(ProKabaddiLoggerConstants.PRO_USER_AUTH_HANDLER
					+ ProKabaddiLoggerConstants.PRO_USER_AUTH_HANDLER_TAR_URL
					+ ProKabaddiLoggerConstants.LOG_ERROR_EXCEPTION);
			return "/prologin?error=#";
		}
	}

	protected void clearAuthenticationAttributes(HttpServletRequest request,
			Authentication authentication) {
		logger.info(ProKabaddiLoggerConstants.PRO_USER_AUTH_HANDLER
				+ ProKabaddiLoggerConstants.PRO_USER_AUTH_HANDLER_CLR_AUTH
				+ ProKabaddiLoggerConstants.LOG_INFO_PARAMS_NO);
		HttpSession session = request.getSession(false);
		if (session == null) {
			return;
		}
		session.removeAttribute(WebAttributes.AUTHENTICATION_EXCEPTION);
		User user = (User) authentication.getPrincipal();
		request.getSession().setAttribute(ProKabaddiConstants.SESSION_UID, user.getUsername());
	}

}

/*---------------------------------------------------------------------------------------
 * Object Name: ProKabaddiLoginController.Java
 * 
 * Modification Block:
 * --------------------------------------------------------------------------------------
 * S.No. Name                Date      Bug Fix no. Desc
 * --------------------------------------------------------------------------------------
 * 1     Seshadri Chowdary          07/08/16  NA          Created
 * --------------------------------------------------------------------------------------
 *
 * Copyright: 2016 <Seshadri Chowdary>
 *---------------------------------------------------------------------------------------*/

package com.prokabaddi.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.prokabaddi.constant.ProKabaddiConstants;
import com.prokabaddi.constant.ProKabaddiLoggerConstants;
import com.prokabaddi.constant.ProKabaddiViewsConstants;
import com.prokabaddi.exception.BaseException;
import com.prokabaddi.exception.ServiceException;
import com.prokabaddi.model.DTO.ProKabaddiDaysDtlDTO;
import com.prokabaddi.service.ProKabaddiService;

/**
 * Process all the login and logout requests and responses
 * 
 * @author Seshadri Chowdary
 * @version 1.0
 */

@Controller
public class ProKabaddiLoginController {

	private static final Logger LOGGER = Logger.getLogger(ProKabaddiLoginController.class);

	@Resource(name = ProKabaddiConstants.USER_SERVICE)
	ProKabaddiService proKabaddiService;

	/**
	 * 
	 * @param error
	 * @param logout
	 * @return
	 */
	@SuppressWarnings(ProKabaddiConstants.NULL)
	@RequestMapping(value = ProKabaddiViewsConstants.PRO_LOGIN, method = RequestMethod.GET)
	public ModelAndView login(
			@RequestParam(value = ProKabaddiConstants.ERROR, required = false) String error,
			@RequestParam(value = ProKabaddiConstants.LOGOUT, required = false) String logout) {
		LOGGER.info(ProKabaddiLoggerConstants.PRO_LOGIN_CTLR
				+ ProKabaddiLoggerConstants.PRO_LOGIN_CTLR_GET
				+ ProKabaddiLoggerConstants.PRO_LOGIN_CTLR_YES + error);
		ModelAndView model = new ModelAndView();
		if (error != null) {
			model.addObject(ProKabaddiConstants.ERROR, ProKabaddiConstants.INVALID_UNAME_PASS);
		} else if (StringUtils.isNotEmpty(error) && error.equals(ProKabaddiConstants.HASHTAG)) {
			model.addObject(ProKabaddiConstants.ERROR, ProKabaddiConstants.NEW_USER);
		}
		if (logout != null) {
			model.addObject(ProKabaddiConstants.MSG, ProKabaddiConstants.LOGOUT_SUCCESS);
		}
		model.addObject(ProKabaddiConstants.MSG, ProKabaddiConstants.SESSION_EXPIRED);
		model.setViewName(ProKabaddiViewsConstants.PRO_LOGIN_VIEW);
		LOGGER.info(ProKabaddiLoggerConstants.PRO_LOGIN_CTLR
				+ ProKabaddiLoggerConstants.PRO_LOGIN_CTLR_GET
				+ ProKabaddiLoggerConstants.PRO_LOGIN_CTLR_YES);
		return model;
	}

	/**
	 * 
	 * @param proKabaddiDaysDtlDTO
	 * @param button
	 * @param modelmap
	 * @param request
	 * @return
	 * @throws ServiceException
	 */
	@RequestMapping(ProKabaddiViewsConstants.PRO_INDEX)
	public String remsindex(
			@ModelAttribute(ProKabaddiConstants.PRO_KABADDI_DTO) ProKabaddiDaysDtlDTO proKabaddiDaysDtlDTO,
			@RequestParam(value = ProKabaddiConstants.BUTTON, required = false) String button,
			ModelMap modelmap, HttpServletRequest request) throws ServiceException {
		LOGGER.info(ProKabaddiLoggerConstants.PRO_LOGIN_CTLR
				+ ProKabaddiLoggerConstants.PRO_LOGIN_CTLR_INDEX
				+ ProKabaddiLoggerConstants.PRO_CTLR_NO_PARAMS);

		List<ProKabaddiDaysDtlDTO> result = null;
		try {
			String path = request.getScheme() + "://" + request.getServerName() + ":"
					+ request.getServerPort() + request.getContextPath();

			if (StringUtils.isNotEmpty(button)) {
				result = proKabaddiService.getMatchesData(
						proKabaddiDaysDtlDTO,
						String.valueOf(request.getSession().getAttribute(
								ProKabaddiConstants.SESSION_UID)), path);
				modelmap.addAttribute("result", result);
			}

			return ProKabaddiViewsConstants.PRO_INDEX_VIEW;

		} catch (BaseException baseEx) {
			LOGGER.error(ProKabaddiLoggerConstants.PRO_LOGIN_CTLR
					+ ProKabaddiLoggerConstants.PRO_LOGIN_CTLR_INDEX
					+ ProKabaddiLoggerConstants.PRO_CTLR_NO_PARAMS + baseEx);
			if (null != baseEx.getErrorCode()
					&& baseEx.getErrorCode().equalsIgnoreCase(ProKabaddiConstants.NULL)) {
				if (baseEx.getErrorCode().startsWith("")) {
					return ProKabaddiViewsConstants.PRO_INDEX_VIEW;
				}
			}
			modelmap.addAttribute(ProKabaddiConstants.ERROR, ProKabaddiConstants.EXCEPTION_ADMIN);
			return ProKabaddiViewsConstants.PRO_INDEX_VIEW;
		}
	}

	/**
	 * 
	 * @return
	 */
	@RequestMapping(ProKabaddiViewsConstants.PRO_LOGIN_SESSIONEXP)
	public String sessionExp() {
		LOGGER.info(ProKabaddiLoggerConstants.PRO_LOGIN_CTLR
				+ ProKabaddiLoggerConstants.PRO_LOGIN_CTLR_SESS_EXP
				+ ProKabaddiLoggerConstants.PRO_CTLR_NO_PARAMS);
		return ProKabaddiViewsConstants.PRO_LOGIN_VIEW;
	}

	/**
	 * 
	 * @return
	 */
	@RequestMapping(ProKabaddiViewsConstants.PRO_LOGIN_AUTHFAIL)
	public String authFail() {
		LOGGER.info(ProKabaddiLoggerConstants.PRO_LOGIN_CTLR
				+ ProKabaddiLoggerConstants.PRO_LOGIN_CTLR_AUTH_FAIL
				+ ProKabaddiLoggerConstants.PRO_CTLR_NO_PARAMS);
		return ProKabaddiViewsConstants.PRO_LOGIN_VIEW;
	}

	/**
	 * 
	 * @return
	 */
	@RequestMapping(ProKabaddiViewsConstants.PRO_LOGIN_BACK)
	public String backToLogin() {
		LOGGER.info(ProKabaddiLoggerConstants.PRO_LOGIN_CTLR
				+ ProKabaddiLoggerConstants.PRO_LOGIN_CTLR_BACK_TO_LOGIN
				+ ProKabaddiLoggerConstants.PRO_CTLR_NO_PARAMS);
		return ProKabaddiViewsConstants.PRO_LOGIN_VIEW;
	}

	/**
	 * 
	 * @param model
	 * @param principal
	 * @param request
	 * @param response
	 * @return
	 */

	@RequestMapping(value = ProKabaddiViewsConstants.PRO_LOOUT, method = RequestMethod.GET)
	public String logoutPage(HttpServletRequest request, HttpServletResponse response) {
		LOGGER.info(ProKabaddiLoggerConstants.PRO_LOGIN_CTLR
				+ ProKabaddiLoggerConstants.PRO_LOGIN_CTLR_LOGOUT
				+ ProKabaddiLoggerConstants.PRO_CTLR_NO_PARAMS);
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (auth != null) {
			new SecurityContextLogoutHandler().logout(request, response, auth);
		}
		return ProKabaddiViewsConstants.REMSLOGIN;
	}

	@RequestMapping("/proSechdule")
	public @ResponseBody String proSechdule(
			@RequestParam(value = "noTeam", defaultValue = "8") String noTeam, ModelMap modelmap) {
		LOGGER.info(ProKabaddiLoggerConstants.PRO_LOGIN_CTLR
				+ ProKabaddiLoggerConstants.PRO_LOGIN_CTLR_LOGOUT
				+ ProKabaddiLoggerConstants.PRO_CTLR_NO_PARAMS);
		List<ProKabaddiDaysDtlDTO> matchs = null;
		String json = null;
		try {
			matchs = proKabaddiService.proSechdule(noTeam);
			Gson gson = new Gson();
			json = gson.toJson(matchs);
			return json;
		} catch (BaseException baseEx) {
			LOGGER.error(ProKabaddiLoggerConstants.PRO_LOGIN_CTLR
					+ ProKabaddiLoggerConstants.PRO_LOGIN_CTLR_LOGOUT
					+ ProKabaddiLoggerConstants.PRO_CTLR_NO_PARAMS + baseEx);
			if (null != baseEx.getErrorCode()
					&& baseEx.getErrorCode().equalsIgnoreCase(ProKabaddiConstants.NULL)) {
				if (baseEx.getErrorCode().startsWith("")) {
					return json;
				}
			}
			modelmap.addAttribute(ProKabaddiConstants.ERROR, ProKabaddiConstants.EXCEPTION_ADMIN);
			return json;
		}
	}
}

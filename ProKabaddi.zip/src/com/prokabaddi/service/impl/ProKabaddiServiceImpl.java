/*---------------------------------------------------------------------------------------
 * Object Name: ProKabaddiServiceImpl.Java
 * 
 * Modification Block:
 * --------------------------------------------------------------------------------------
 * S.No. Name                Date      Bug Fix no. Desc
 * --------------------------------------------------------------------------------------
 * 1     Seshadri Chowdary          07/08/16  NA          Created
 * --------------------------------------------------------------------------------------
 *
 * Copyright: 2016 <Seshadri Chowdary>
 *---------------------------------------------------------------------------------------*/
package com.prokabaddi.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.tomcat.util.codec.binary.Base64;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.prokabaddi.builder.DoubleRoundRabiBuilder;
import com.prokabaddi.constant.ProKabaddiConstants;
import com.prokabaddi.constant.ProKabaddiLoggerConstants;
import com.prokabaddi.exception.ServiceException;
import com.prokabaddi.model.DTO.ProKabaddiDaysDtlDTO;
import com.prokabaddi.service.ProKabaddiService;

@Component
@Service(ProKabaddiConstants.USER_SERVICE)
@Transactional(propagation = Propagation.REQUIRED)
public class ProKabaddiServiceImpl implements ProKabaddiService {
	private static Logger LOGGER = Logger.getLogger(ProKabaddiServiceImpl.class);

	@Override
	public List<ProKabaddiDaysDtlDTO> proSechdule(String noTeam) throws ServiceException {
		LOGGER.info(ProKabaddiLoggerConstants.PRO_USER_SERVICE
				+ ProKabaddiLoggerConstants.PRO_USER_EDIT
				+ ProKabaddiLoggerConstants.PRO_CTLR_PARAM_YES);
		try {
			List<String> teamsList = null;
			if (null != noTeam) {
				teamsList = new ArrayList<String>();
				for (int i = 1; i <= Integer.parseInt(noTeam); i++) {
					teamsList.add(i + "");
				}
			}
			List<ProKabaddiDaysDtlDTO> matchs = DoubleRoundRabiBuilder
					.btnTeamFixturesClick(teamsList);
			return matchs;
		} catch (NullPointerException nullPointerEx) {
			// releaseEntityMgrForRollback(entityManager);
			LOGGER.error(ProKabaddiLoggerConstants.PRO_USER_SERVICE
					+ ProKabaddiLoggerConstants.PRO_USER_EDIT
					+ ProKabaddiLoggerConstants.LOG_ERROR_EXCEPTION + nullPointerEx);
			throw new ServiceException(ProKabaddiConstants.NULL_POINTER_EXCEPTION, nullPointerEx);
		} catch (Exception otherEx) {
			// releaseEntityMgrForRollback(entityManager);
			LOGGER.error(ProKabaddiLoggerConstants.PRO_USER_SERVICE
					+ ProKabaddiLoggerConstants.PRO_USER_EDIT
					+ ProKabaddiLoggerConstants.LOG_ERROR_EXCEPTION + otherEx);
			throw new ServiceException(ProKabaddiConstants.SERVICE_EXCEPTION, otherEx);
		}
	}

	@Override
	public List<ProKabaddiDaysDtlDTO> getMatchesData(ProKabaddiDaysDtlDTO proKabaddiDaysDtlDTO,
			String userId, String path) throws ServiceException {
		LOGGER.info(ProKabaddiLoggerConstants.PRO_USER_SERVICE
				+ ProKabaddiLoggerConstants.PRO_USER_EDIT
				+ ProKabaddiLoggerConstants.PRO_CTLR_PARAM_YES);
		try {
			final String url = path + "/proSechdule?noTeam=" + proKabaddiDaysDtlDTO.getTeams();

			String plainCreds = userId + ":" + userId;
			byte[] plainCredsBytes = plainCreds.getBytes();
			byte[] base64CredsBytes = Base64.encodeBase64(plainCredsBytes);
			String base64Creds = new String(base64CredsBytes);

			HttpHeaders headers = new HttpHeaders();
			headers.add("Authorization", "Basic " + base64Creds);
			RestTemplate restTemplate = new RestTemplate();
			HttpEntity<String> request = new HttpEntity<String>(headers);
			ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, request,
					String.class);
			String jsonText = response.getBody();

			ObjectMapper mapper = new ObjectMapper();

			ProKabaddiDaysDtlDTO[] proKabaddiDaysDtlDTOlist = mapper.readValue(jsonText + "",
					ProKabaddiDaysDtlDTO[].class);
			System.out.println(proKabaddiDaysDtlDTOlist);
			return Arrays.asList(proKabaddiDaysDtlDTOlist);
		} catch (NullPointerException nullPointerEx) {
			// releaseEntityMgrForRollback(entityManager);
			LOGGER.error(ProKabaddiLoggerConstants.PRO_USER_SERVICE
					+ ProKabaddiLoggerConstants.PRO_USER_EDIT
					+ ProKabaddiLoggerConstants.LOG_ERROR_EXCEPTION + nullPointerEx);
			throw new ServiceException(ProKabaddiConstants.NULL_POINTER_EXCEPTION, nullPointerEx);
		} catch (Exception otherEx) {
			otherEx.printStackTrace();
			// releaseEntityMgrForRollback(entityManager);
			LOGGER.error(ProKabaddiLoggerConstants.PRO_USER_SERVICE
					+ ProKabaddiLoggerConstants.PRO_USER_EDIT
					+ ProKabaddiLoggerConstants.LOG_ERROR_EXCEPTION + otherEx);
			throw new ServiceException(ProKabaddiConstants.SERVICE_EXCEPTION, otherEx);
		}
	}

	protected HttpEntity<?> getHttpEntity() {
		return new HttpEntity<List<ProKabaddiDaysDtlDTO>>(getHttpHeaders());
	}

	protected HttpHeaders getHttpHeaders() {
		HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		String auth = "demo" + ":" + "demo";
		String authHeader = "Basic " + new String(auth);
		requestHeaders.set("Authorization", authHeader);
		return requestHeaders;
	}

}

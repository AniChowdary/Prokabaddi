/*---------------------------------------------------------------------------------------
 * Object Name: ProKabaddiViewsConstants.Java
 * 
 * Modification Block:
 * --------------------------------------------------------------------------------------
 * S.No. Name                Date      Bug Fix no. Desc
 * --------------------------------------------------------------------------------------
 * 1     Seshadri Chowdary          07/08/16  NA          Created
 * --------------------------------------------------------------------------------------
 *
 * Copyright: 2016 <Seshadri Chowdary>
 *---------------------------------------------------------------------------------------*/

package com.prokabaddi.constant;

/**
 * Class which will provides the String final constants i.e JSP names, request
 * handler mappings, request parameters , strings and error codes.
 */

public final class ProKabaddiViewsConstants {

	// View
	// Login
	public static final String PRO_LOGIN_REDIRECT = "login:redirect?accessDenied=true";
	public static final String PRO_LOGIN_SESSIONEXP = "/sessionExp";
	public static final String PRO_LOGIN_AUTHFAIL = "/authFail";
	public static final String PRO_LOGIN_BACK = "/back";
	public static final String PRO_LOOUT = "/logout";
	public static final String PRO_LOGIN_VIEW = "login";
	public static final String LOGOUT = "logout";

	public static final String REMSLOGIN = "/login";
	public static final String PRO_LOGIN = "/prologin";

	public static final String PRO_INDEX = "/proIndex";
	public static final String PRO_INDEX_VIEW = "proIndex";

}

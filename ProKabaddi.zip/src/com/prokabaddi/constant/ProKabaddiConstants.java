/*---------------------------------------------------------------------------------------
 * Object Name: ProKabaddiConstants.Java
 * 
 * Modification Block:
 * --------------------------------------------------------------------------------------
 * S.No. Name                Date      Bug Fix no. Desc
 * --------------------------------------------------------------------------------------
 * 1     Seshadri Chowdary          07/08/16  NA          Created
 * --------------------------------------------------------------------------------------
 *
 * Copyright: 2016 <Seshadri Chowdary>
 *---------------------------------------------------------------------------------------*/

package com.prokabaddi.constant;

/**
 * Class which will provides the String final constants i.e JSP names, request
 * handler mappings, request parameters , strings and error codes.
 */

public final class ProKabaddiConstants {
	public static final String SCOPE_SESSION = "session";

	public static final int BUFFER_SIZE = 4096;

	public static final String UNCHECKED = "unchecked";

	public static final String MM_DD_YYYY = "MM/dd/yyyy";
	public static final String DD_MM_YYYY = "dd/MM/yyyy";
	public static final String DDMMYYYY_HHMMSS = "dd-MM-yyyy hh:mm:ss a zzz";

	public static final String HASHTAG = "#";

	public static final String ERROR_MESSAGE = "Exception Occurred Contact Admin!!!";
	public static final String ERROR = "error";
	public static final String NO_RECORDS = "No Records found";

	public static final String EXCEPTION_ADMIN = "Exception Occurred Contact Admin!!!";

	// Data Source
	public static final String DS_NAME = "remsDS";
	// download param
	public static final String APP_STREAM = "application/octet-stream";
	public static final String HEADER_DISP = "Content-Disposition";
	public static final String ATTACHMENT = "attachment; filename=\"%s\"";
	public static final String FILE_PATH_USER_MANUAL = "/download/BusinessDateUpdateExcel.xlsx";
	// persistent units
	public static final String PERSISTENCE_UNIT_USER = "persistenceUnit";

	// Prams
	public static final String CURRENT_PAGE = "currentPage";
	public static final String START_PAGE = "startPage";
	public static final String LAST_PAGE = "lastPage";
	public static final String PAGE = "page";
	public static final String NO_OF_PAGES = "noOfPages";
	public static final String ID = "id";
	public static final String U_ID = "uid";
	public static final String SESSION_UID = "UserId";
	public static final String SESSION_UNAME = "UserName";

	public static final String APP_ID = "appId";
	public static final String ENV_ID = "envId";
	public static final String NAME = "name";

	public static final String Y = "Y";
	public static final String N = "N";
	public static final String SINGLE_QUTE = "'";
	public static final String DOUBLE_QUTE = "','";

	public static final String ROLE = "ROLE";
	public static final String ROLE_ADMIN = "ROLE_ADMIN";
	public static final String ROLE_USER = "ROLE_USER";
	public static final String ROLE_ENV_OWNR = "ROLE_ENV_OWNR";
	public static final String ROLE_INVALID = "ROLE_INVALID";

	public static final String MSG = "msg";
	public static final String USER_ID = "userId";

	public static final String NULL = "null";
	public static final String ON_DT = "onDt";
	public static final String NXT_DT = "nxtDt";
	public static final String BOOK_DT = "bookDate";
	public static final String ENV_NAME = "envName";
	public static final String APP_NAME = "appName";
	public static final String BOOK_ID = "bookId";
	public static final String DEC = "dec";
	public static final String BUS = "bus";
	public static final String REASON = "reason";
	public static final String UNDERSCORE = "_";

	public static final String UNAME = "USER_NAME";
	public static final String UTYPE = "USER_TYPE";

	public static final String PROP_FILE = "/properties/db.properties";
	public static final String DRIVER = "db.driver";
	public static final String URL = "db.url";
	public static final String USER = "db.user";
	public static final String PASS = "db.pass";

	public static final String REQUESTED = "Requested";
	public static final String LOGOUT = "logout";
	public static final String INVALID_UNAME_PASS = "Invalid username and password!";
	public static final String LOGOUT_SUCCESS = "You've been logged out successfully.";
	public static final String SESSION_EXPIRED = "You are not allowed to perform 'Back' or You have not logged in or Session Expired.";
	public static final String NEW_USER = "You are not a registered user, Please request for providing the access.";

	// Exception
	public static final String NRE_ENTITY_MGR_FACTORY_CLOSED_EXCEPTION = "NRE_0106";
	public static final String INVALID_QUERY_EXCEPTION = "11200";
	public static final String NULL_POINTER_EXCEPTION = "11201";
	public static final String DATABASE_EXCEPTION = "11202";
	public static final String SERVICE_EXCEPTION = "11203";
	public static final String IE_EXCEPTION = "11204";
	public static final String PARSE_EXCEPTION = "11205";

	public static final String ZERO = "0";
	public static final String ONE = "1";

	// Resource names
	public static final String UTIL_SERVICE = "remsUtilService";
	public static final String USER_SERVICE = "remsUserService";
	public static final String APP_SERVICE = "remsAppService";
	public static final String ENV_SERVICE = "remsEnvService";
	public static final String BOOK_SERVICE = "remsBookService";
	public static final String UTIL_DAO = "remsUtilDAO";
	public static final String APP_DAO = "remsAppDAO";
	public static final String ENV_DAO = "remsEnvDAO";
	public static final String USER_DAO = "remsUserDAO";
	public static final String BOOK_DAO = "remsBookDAO";
	// Resource DTOs

	// User
	public static final String PRO_USER_DTO = "remsUserDtlDTO";
	public static final String PRO_USER_DTOS = "remsUserDtlDTOs";
	public static final String PRO_USER_APP_ACC_DTO = "remsUserAppAccessDTO";
	public static final String PRO_USER_APP_ACC_DTOS = "remsUserAppAccessDTOs";
	// Apps
	public static final String PRO_APPS_DTO = "remsAppsDtlDTO";
	public static final String PRO_APPS_DTOS = "remsAppsDtlDTOs";

	// Env
	public static final String PRO_ENV_DTO = "remsEnvDtlDTO";
	public static final String PRO_BUS_DATE_DTO = "remsBusDateDTO";

	public static final String PRO_ENV_DTOS = "remsEnvDtlDTOs";

	public static final String PRO_ENV_SERVER_DTO = "remsEnvServerDTO";
	public static final String PRO_ENV_SERVER_DTOS = "remsEnvServerDTOs";

	// Booking
	public static final String PRO_BOOK_DTO = "remsBookDtlDTO";
	public static final String PRO_BOOK_DTOS = "remsBookDtlDTOs";
	public static final String PRO_BOOK_BUS_DT_DTOS = "remsBookBusDateDTOs";

	public static final String PRO_SEARCH_BOOK_DTO = "remsSearchBookingDTO";
	public static final String PRO_APP_LIST = "appList";

	public static final String PRO_BOOK_S = "Shared";
	public static final String PRO_BOOK_D = "Dedicated";

	public static final String OVERLAP_MSG = "overlap";
	public static final String EXCEL_ERROR = "excelError";
	public static final String OVERLAP_MSG_DTL = "Booking date overlaped.";

	public static final String EXCEL_ERROR1 = "Application ID not matching. \n";
	public static final String EXCEL_ERROR2 = "Env ID not matching. \n";
	public static final String EXCEL_ERROR3 = "Start date not matching. \n";
	public static final String EXCEL_ERROR4 = "End date not matching. \n";

	public static final String EXCEL_ERROR11 = "Application ID cannot be null. \n";
	public static final String EXCEL_ERROR12 = "Env ID  cannot be null. \n";
	public static final String EXCEL_ERROR13 = "Start date  cannot be null. \n";
	public static final String EXCEL_ERROR14 = "End date  cannot be null. \n";

	public static final String SUCCESS = "success";

	public static final String PRO_REPORT_NAME = "Booking Report";

	public static final String PRO_BOOKING_REPORT_DTOS = "remsBookingReportDTOs";
	public static final String PRO_BOOKING_REPORT_ID = "remsBookingReport";
	public static final String RAW_TYPES = "rawtypes";
	public static final String SUBJECT_FORGOTPASS = "Sent Your new password";
	public static final String NEW_MSG = "newMessage";
	public static final String PROP_FORGOTPASS_VM = "properties/forgotPassword.vm";
	public static final String UTF_8 = "UTF-8";

	public static final String GO = "go";

	public static final String UPDATE = "updateBus";

	public static final String BUTTON = "submit";

	public static final String PRO_KABADDI_DTO = "proKabaddiDaysDtlDTO";
}

﻿function deleteSel(url,from){
	
	$("#myModal").modal('show');
	$('#from').html(from).fadeIn();
	$('#url').attr('id', url);
	$(".del").click(function(){
		window.location.href = $(".del").attr("id");
	});
}  


	function loadAjax(){
	  $("#ajaxloader").show();
	}  



(function ($) {
    "use strict";
    var mainApp = {

        metisMenu: function () {

            /*====================================
            METIS MENU 
            ======================================*/

            $('#main-menu').metisMenu();

        },


        loadMenu: function () {

            /*====================================
            LOAD APPROPRIATE MENU BAR
         ======================================*/

            $(window).bind("load resize", function () {
                if ($(this).width() < 768) {
                    $('div.sidebar-collapse').addClass('collapse')
                } else {
                    $('div.sidebar-collapse').removeClass('collapse')
                }
            });
        },
        slide_show: function () {

            /*====================================
           SLIDESHOW SCRIPTS
        ======================================*/

            $('#carousel-example').carousel({
                interval: 3000 // THIS TIME IS IN MILLI SECONDS
            })
        },
        reviews_fun: function () {
            /*====================================
         REWIEW SLIDE SCRIPTS
      ======================================*/
            $('#reviews').carousel({
                interval: 2000 //TIME IN MILLI SECONDS
            })
        },
        
       
        
    };
    $(document).ready(function () {
        mainApp.metisMenu();
        mainApp.loadMenu();
        mainApp.slide_show();
        mainApp.reviews_fun();
       
    });
}(jQuery));
 

function remsBookEnvFormValidation(){
	var formObj = $("#remsBookEnvForm");
	var buttonObj = formObj.find('.btn-info');
	//It expands all the Panels to see the errors
 
	//form validation rules
	formObj.validate({
		rules: {
 
			 
			bookReqtEmail:{
				required: true,
				email: true,
				minlength:8,
				maxlength:50
  			}, 
  			bookReqtPh:{
  				required: true,
  				minlength:8,
				maxlength:20
 			} 
		},
		messages: {
			 
			bookReqtEmail:{
				maxlength:'Email Cannot be more than 50 characters',
				email:'You have entered an invalid Email.  The acceptable value is sample@example.com'
			},
			bookReqtPh:{
				maxlength:'Phone cannot be more than 20 digits.',
				minlength:'Phone cannot be less than 8 digits.',
				number:'Enter a valid phone number'
			}  
		},
		submitHandler: function(form) {
			loadAjax();
			form.submit();
		},
		invalidHandler: function(form, validator){
			//error_invalidHandler(buttonObj);
		},
		onfocusout: function(element, event){
			removeError(buttonObj);
		}
	});
}
   


//Remove message handler for validation
function removeError(btnObj){
	
	var msgPlacement = btnObj.closest('.rghtCol');		
	if(btnObj.parents('.popup').length){
		msgPlacement = btnObj.parents('.popup').find('form:eq(0)');
	}
	
	msgPlacement.find('.successBox').remove();
	msgPlacement.find('.failureBox').remove();
}


function closeMsgListner(){
	$(".alert-box .close").bind('click',function(){
		$(this).closest('div').fadeOut('100',function(){
			$(this).remove();
		});
	});
}





//Code Phone Val Starts

function validatePhone(phoneNo) {
    var a = document.getElementById(phoneNo).value;
    //var filter = /^[0-9-+]+$/; + and -
    var filter = /^[-,+]*[0-9][-,+0-9]*$/;
    
    if (filter.test(a)) {
        return true;
    }
    else {
        return false;
    }
}
// Ends







